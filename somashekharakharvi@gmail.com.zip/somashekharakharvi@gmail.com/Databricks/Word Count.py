# Databricks notebook source
counts = sc.textFile("/FileStore/tables/new.txt")
counts.collect()

# COMMAND ----------

# MAGIC %run /Users/somashekharakharvi@gmail.com/Databricks/RDD

# COMMAND ----------

print(variable_a)

# COMMAND ----------

