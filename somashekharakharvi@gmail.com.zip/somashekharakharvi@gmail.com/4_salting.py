# Databricks notebook source
# MAGIC %md
# MAGIC <h2> Imports & Configuration </h2>

# COMMAND ----------

from IPython.core.interactiveshell import InteractiveShell
InteractiveShell.ast_node_interactivity = 'all'

# COMMAND ----------

from pyspark.sql.types import *
import pyspark.sql.functions as F
from pyspark.sql import SparkSession

# COMMAND ----------

spark = SparkSession.builder.master("local[*]").getOrCreate()

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "3")
spark.conf.get("spark.sql.shuffle.partitions")
spark.conf.set("spark.sql.adaptive.enabled", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC <h2> Simulating Skewed Join </h2>

# COMMAND ----------

df_uniform = spark.createDataFrame([i for i in range(1000000)], IntegerType())
df_uniform.show(5, False)

# COMMAND ----------

(
    df_uniform
    .withColumn("partition", F.spark_partition_id())
    .groupBy("partition")
    .count()
    .orderBy("partition")
    .show(15, False)
)

# COMMAND ----------

df0 = spark.createDataFrame([0] * 999990, IntegerType()).repartition(1)
df1 = spark.createDataFrame([1] * 15, IntegerType()).repartition(1)
df2 = spark.createDataFrame([2] * 10, IntegerType()).repartition(1)
df3 = spark.createDataFrame([3] * 5, IntegerType()).repartition(1)
df_skew = df0.union(df1).union(df2).union(df3)
df_skew.show(5, False)

# COMMAND ----------

(
    df_skew
    .withColumn("partition", F.spark_partition_id())
    .groupBy("partition")
    .count()
    .orderBy("partition")
    .show()
)

# COMMAND ----------

df_joined_c1 = df_skew.join(df_uniform, "value", 'inner')

# COMMAND ----------

df_joined_c1.rdd.getNumPartitions()

# COMMAND ----------

df_joined_c1.explain()

# COMMAND ----------

df_joined_c1\
    .withColumn("partition", F.spark_partition_id())\
    .groupBy("partition")\
    .count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC <h2> Simulating Uniform Distribution Through Salting </h2>

# COMMAND ----------

SALT_NUMBER = int(spark.conf.get("spark.sql.shuffle.partitions"))
SALT_NUMBER

# COMMAND ----------

df_skew = df_skew.withColumn("salt", (F.rand() * SALT_NUMBER).cast("int"))

# COMMAND ----------

df_skew.show(10, truncate=False)

# COMMAND ----------

df_uniform = (
    df_uniform
    .withColumn("salt_values", F.array([F.lit(i) for i in range(SALT_NUMBER)]))
    .withColumn("salt", F.explode(F.col("salt_values")))
)

# COMMAND ----------

df_uniform.show(10, truncate=False)

# COMMAND ----------

df_joined = df_skew.join(df_uniform, ["value", "salt"], 'inner')

# COMMAND ----------

(
    df_joined
    .withColumn("partition", F.spark_partition_id())
    .groupBy("value", "partition")
    .count()
    .orderBy("value", "partition")
    .show()
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Salting In Aggregations

# COMMAND ----------

df_skew.groupBy("value").count().show()

# COMMAND ----------

(
    df_skew
    .withColumn("salt", (F.rand() * SALT_NUMBER).cast("int"))
    .groupBy("value", "salt")
    .agg(F.count("value").alias("count"))
    .groupBy("value")
    .agg(F.sum("count").alias("count"))
    .show()
)

# COMMAND ----------

spark.stop()