# Databricks notebook source
# MAGIC %md
# MAGIC <h2> Imports & Configuration </h2>

# COMMAND ----------

from IPython.core.interactiveshell import InteractiveShell
InteractiveShell.ast_node_interactivity = 'all'

import warnings
warnings.filterwarnings('ignore')
warnings.simplefilter('ignore')
import time

# COMMAND ----------

from pyspark.sql.types import IntegerType
import pyspark.sql.functions as F
from pyspark.sql import SparkSession

# COMMAND ----------

spark = SparkSession.builder.master("local[4]").getOrCreate()
sc = spark.sparkContext
sc.setLogLevel("ERROR")

# COMMAND ----------

# spark.conf.set("spark.sql.shuffle.partitions", "3")
spark.conf.set("spark.sql.adaptive.enabled", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC <h2> Simulating Uniform Dataset </h2>

# COMMAND ----------

df_uniform = spark.range(1000000)
df_uniform.show(3, False)

# COMMAND ----------

(
    df_uniform
    .withColumn("partition", F.spark_partition_id())
    .groupBy("partition")
    .count()
    .orderBy("partition")
    .show()
)

# COMMAND ----------

# MAGIC %md
# MAGIC <h2> Skewed Dataset </h2>

# COMMAND ----------

df0 = spark.range(0, 1000000).repartition(1)
df1 = spark.range(0, 10).repartition(1)
df2 = spark.range(0, 10).repartition(1)
df_skew = df0.union(df1).union(df2)
df_skew.show(3, False)

# COMMAND ----------

(
    df_skew
    .withColumn("partition", F.spark_partition_id())
    .groupBy("partition")
    .count()
    .orderBy("partition")
    .show()
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Join Skews

# COMMAND ----------

transactions_file = "../../data/data_skew/transactions.parquet"
customer_file = "../../data/data_skew/customers.parquet"

df_transactions = spark.read.parquet(transactions_file)
df_customers = spark.read.parquet(customer_file)

# COMMAND ----------

df_transactions.printSchema()
df_transactions.show(5, False)

# COMMAND ----------

df_customers.printSchema()
df_customers.show(5, False)

# COMMAND ----------

(
    df_transactions
    .groupBy("cust_id")
    .agg(F.countDistinct("txn_id").alias("ct"))
    .orderBy(F.desc("ct"))
    .show(5, False)
)

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

df_txn_details = (
    df_transactions.join(
        df_customers,
        on="cust_id",
        how="inner"
    )
)

# COMMAND ----------

start_time = time.time()
df_txn_details.count()
print(f"time taken: {time.time() - start_time}")

# COMMAND ----------

# spark.stop()