# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC Documentation will be provided for you in the exam.
# MAGIC * Login to Academy and go to the certification exam details page.
# MAGIC * Review by going through the link relevant to Python API Docs.

# COMMAND ----------

