# Databricks notebook source
print("this is child")

# COMMAND ----------

dbutils.notebook.exit(100)

# COMMAND ----------

