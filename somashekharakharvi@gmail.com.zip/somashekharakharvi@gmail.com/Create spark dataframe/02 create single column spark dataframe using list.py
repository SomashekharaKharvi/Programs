# Databricks notebook source
spark


# COMMAND ----------

age_list=[1,2,3,4,5]
name_list=['suraj','panna']

# COMMAND ----------

spark.createDataFrame(age_list,'int')

# COMMAND ----------

spark.createDataFrame(name_list,'string').show()

# COMMAND ----------

age_list=[(1,),(2,),(3,)]

# COMMAND ----------

spark.createDataFrame(age_list,'val int').show()

# COMMAND ----------

data=[(1,'suraj'),(2,'namitha'),(3,'praveen')]

# COMMAND ----------

spark.createDataFrame(data,'no int,name string').show()

# COMMAND ----------

user_list=[[1,'suraj'],[2,'namitha'],[3,'praveen']]

# COMMAND ----------

spark.createDataFrame(user_list,'no int, name string')

# COMMAND ----------

from pyspark.sql import Row

# COMMAND ----------

user_row=[Row(*user) for user in user_list]

# COMMAND ----------

user_row

# COMMAND ----------

user_details=[
  {'user_id':1,'name':'suraj'},
  {'user_id':2,'name':'namitha'}
]

# COMMAND ----------

user_row=[Row(**user) for user in user_details]

# COMMAND ----------

user_row

# COMMAND ----------

df=spark.createDataFrame(user_row, ' user_id int, name string')

# COMMAND ----------

df.printSchema()

# COMMAND ----------

