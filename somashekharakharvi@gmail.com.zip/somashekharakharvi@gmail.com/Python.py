# Databricks notebook source
def fuc():
    pattern='abba'
    string="dog cat cat dog"
    words = string.split(" ")
    if len(pattern) != len(words):
        print("false")
    
    # Create two dictionaries for mapping
    char_to_word = {}
    word_to_char = {}
    
    for char, word in zip(pattern, words):
        print(char, word)
        if char in char_to_word:
            if char_to_word[char]!= word:
                return False
        else:
            char_to_word[char]=word
        
        if word in word_to_char:
           if word_to_char[word]!= char:
             return False
            
        else:
           word_to_char[word]=char
        
    return True
    
print(fuc())

# COMMAND ----------

import time

time.sleep(9999999)

# COMMAND ----------

# from pyspark.sql import SparkSession

# # Step 1: Create a Spark session
# spark = SparkSession.builder \
#     .appName("Create Dataset Example") \
#     .master("local[*]") \  # Use local mode for testing
#     .getOrCreate()

# Step 2: Create a list of dictionaries
data = [
    {"name": "Alice", "age": 30},
    {"name": "Bob", "age": 25},
    {"name": "Cathy", "age": 28}
]

# Step 3: Create a DataFrame (Dataset)
people_df = spark.createDataFrame(data)

# Show the DataFrame
people_df.show()

# COMMAND ----------

def func():

  pattern='abba'
  string="dog cat cat dog"
  words=string.split(" ")

  if len(pattern)!=len(words):
    return False

  char_to_word={}
  word_to_char={}
  for char, word in zip(pattern, words):
    print (char, word)
    if char in char_to_word:
      if char_to_word[char]!=word:
        return False
    else:
      char_to_word[char]=word

    if word in word_to_char:
      if word_to_char[word]!=char:
        return False
    else:
      word_to_char[word]=char

  return True   

print(func())


# COMMAND ----------

l=[1,2,3 , 4, 5, 6, 7, 8]
odd=[]

even=[]
for i in l:
  if i%2==0:
    even.append(i)
  else:
    odd.append(i)
res=[]
for i in range(len(odd)):
  res.append((odd[i], even[i]),)

print(res)