# Databricks notebook source
# DBTITLE 1,climbStairs
def climbStairs(n):
    if n <= 1:
        return 1

    one, two = 1, 1

    for i in range(n - 1):
        temp = one
        one = one + two  # Corrected to use 'two'
        two = temp

    return one

# Test the function
print(climbStairs(5))  # Output: 8

# COMMAND ----------

def generate(numRows):
  res=[[1]]

  for i in range(numRows-1):
    temp=[0]+res[-1]+[0]
    row=[]
    for j in range(len(res[-1])+1):
      row.append(temp[j]+ temp[j+1])
    res.append(row)
   
  return res
print(generate(5))
