# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql import Window
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.types import *

# COMMAND ----------

from pyspark.sql.types import *
data=[
  (1, 2, None),
  (None, 3, None),
  (5, None, None)
]
schema= StructType([
  StructField('col1', IntegerType(), True),
  StructField('col2', IntegerType(), True),
  StructField('col3', IntegerType(), True)
]
)
df=spark.createDataFrame(data,schema)
df.display()

# COMMAND ----------

df.first()[col2][0]

# COMMAND ----------

df1_columns=[ c for c in df1.columns if df1.first()[c]]
df1_columns

# COMMAND ----------

